#!/usr/bin/env bash
set -u
export PAPER_ROOT=/ceph/dwong/agent_paper_B
export AR_HARNESS_ROOT=/ceph/dwong/r1_prepare_20261025/autoresearch_harness
export WORK=/tmp/r1_d28_liveness_20261027_attempt02
export TMPDIR="$WORK"
export PATH=/ceph/dwong/r1_prepare_20261025/venv/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda-11.8/lib64:/opt/rh/gcc-toolset-13/root/usr/lib64
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1
cd "$PAPER_ROOT" || exit 1
python "$WORK/phase6_repair_liveness.py"
rc=$?
printf "D28_DRIVER_EXIT=%s\n" "$rc"
exit "$rc"
